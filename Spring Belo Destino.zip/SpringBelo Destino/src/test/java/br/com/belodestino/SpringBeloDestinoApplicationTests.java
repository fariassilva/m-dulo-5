package br.com.belodestino;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBeloDestinoApplicationTests {

	@Test
	void contextLoads() {
	}

}
