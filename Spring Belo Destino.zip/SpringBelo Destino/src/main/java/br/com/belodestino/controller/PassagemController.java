package br.com.belodestino.controller;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

//import br.com.belodestino.repository.PassagemRepository;

@Controller
public class PassagemController {
	
	//@Autowired
	//private PassagemRepository passagemRepository;


	
	
	
}
