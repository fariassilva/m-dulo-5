package br.com.belodestino.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.belodestino.model.Cargo;

public interface CargoRepository extends JpaRepository<Cargo, Long> {

}
