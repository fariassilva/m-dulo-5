package br.com.belodestino.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.belodestino.model.Unidade;

public interface UnidadeRepository extends JpaRepository<Unidade, Long> {

}
